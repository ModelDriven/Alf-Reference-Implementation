package org.modeldriven.alf.uml;

public interface Parameter extends TypedElement, MultiplicityElement {

    public ParameterDirectionKind getDirection();   

}
