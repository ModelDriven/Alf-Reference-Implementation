package org.modeldriven.alf.uml;

public interface ParameterableElement extends Element {
    
    public TemplateParameter getTemplateParameter();

}
