package org.modeldriven.alf.uml;

public interface TemplateParameter extends Element {
    
    public ParameterableElement getParameteredElement();

}
