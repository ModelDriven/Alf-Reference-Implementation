package org.modeldriven.alf.uml;

public interface Primitive extends DataType {

}
