package org.modeldriven.alf.uml;

public interface DataType extends Classifier {

}
