package org.modeldriven.alf.uml;

public interface Reception extends BehavioralFeature {

    public Element getSignal();

}
