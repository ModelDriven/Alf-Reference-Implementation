package org.modeldriven.alf.uml;

public interface Signal extends Classifier {

}
