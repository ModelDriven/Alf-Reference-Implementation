package org.modeldriven.alf.uml;

public interface Enumeration extends DataType {

}
