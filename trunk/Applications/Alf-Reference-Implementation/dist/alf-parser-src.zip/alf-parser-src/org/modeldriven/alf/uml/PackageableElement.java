package org.modeldriven.alf.uml;

public interface PackageableElement extends NamedElement {

}
