package org.modeldriven.alf.uml;

public interface Class extends BehavioredClassifier {

    public boolean getIsActive();

}
