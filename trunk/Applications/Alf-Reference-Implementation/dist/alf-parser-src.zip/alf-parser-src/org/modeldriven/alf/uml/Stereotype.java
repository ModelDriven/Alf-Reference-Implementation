package org.modeldriven.alf.uml;

public interface Stereotype extends Class {

}
