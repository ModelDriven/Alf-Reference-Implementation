package org.modeldriven.alf.uml;

public interface BehavioredClassifier extends Classifier {
    
    public Behavior getClassifierBehavior();

}
