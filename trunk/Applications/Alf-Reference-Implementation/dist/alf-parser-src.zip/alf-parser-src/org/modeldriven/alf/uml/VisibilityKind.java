package org.modeldriven.alf.uml;

public enum VisibilityKind {
    public_, private_, protected_, package_
}
