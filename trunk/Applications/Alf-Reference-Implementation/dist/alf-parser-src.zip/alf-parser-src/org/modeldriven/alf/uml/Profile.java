package org.modeldriven.alf.uml;

public interface Profile extends Package {

}
