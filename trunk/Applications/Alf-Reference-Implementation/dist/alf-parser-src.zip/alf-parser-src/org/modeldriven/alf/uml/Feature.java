package org.modeldriven.alf.uml;

public interface Feature extends NamedElement {

}
