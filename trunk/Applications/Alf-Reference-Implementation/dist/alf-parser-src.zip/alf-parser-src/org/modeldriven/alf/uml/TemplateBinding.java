package org.modeldriven.alf.uml;

public interface TemplateBinding extends Element {
    
    public TemplateSignature getSignature();
    
}
