package org.modeldriven.alf.uml;

public interface Activity extends Behavior {

}
