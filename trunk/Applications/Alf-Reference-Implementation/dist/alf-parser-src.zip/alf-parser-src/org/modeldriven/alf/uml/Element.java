package org.modeldriven.alf.uml;

public interface Element {
    public String toString(boolean includeDerived);   
    public void print(String prefix);
}
