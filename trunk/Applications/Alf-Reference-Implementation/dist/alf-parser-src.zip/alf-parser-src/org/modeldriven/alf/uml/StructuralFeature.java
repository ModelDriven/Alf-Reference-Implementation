package org.modeldriven.alf.uml;

public interface StructuralFeature extends 
    Feature, TypedElement, MultiplicityElement {

}
