package org.modeldriven.alf.uml;

public interface EnumerationLiteral extends PackageableElement {

    public Enumeration getEnumeration();

}
