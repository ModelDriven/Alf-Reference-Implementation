package org.modeldriven.alf.uml;

public interface Type extends PackageableElement {

}
