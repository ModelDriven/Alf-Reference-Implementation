
/*
 * Copyright 2011 Data Access Technologies, Inc. (Model Driven Solutions)
 *
 * Licensed under the Academic Free License version 3.0 
 * (http://www.opensource.org/licenses/afl-3.0.php) 
 *
 */

package org.modeldriven.alf.syntax.expressions;

import org.modeldriven.alf.syntax.*;
import org.modeldriven.alf.syntax.common.*;
import org.modeldriven.alf.syntax.expressions.*;
import org.modeldriven.alf.syntax.statements.*;
import org.modeldriven.alf.syntax.units.*;

import org.modeldriven.alf.uml.Element;
import org.modeldriven.alf.uml.Profile;
import org.modeldriven.alf.uml.Stereotype;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.modeldriven.alf.syntax.expressions.impl.ArithmeticExpressionImpl;

/**
 * A binary expression with an arithmetic operator.
 **/

public class ArithmeticExpression extends BinaryExpression {

	public ArithmeticExpression() {
		this.impl = new ArithmeticExpressionImpl(this);
	}

	public ArithmeticExpressionImpl getImpl() {
		return (ArithmeticExpressionImpl) this.impl;
	}

	public Boolean getIsConcatenation() {
		return this.getImpl().getIsConcatenation();
	}

	public void setIsConcatenation(Boolean isConcatenation) {
		this.getImpl().setIsConcatenation(isConcatenation);
	}

	/**
	 * An arithmetic expression is a string concatenation expression if its type
	 * is String.
	 **/
	public boolean arithmeticExpressionIsConcatenationDerivation() {
		return this.getImpl().arithmeticExpressionIsConcatenationDerivation();
	}

	/**
	 * The type of an arithmetic expression is the same as the type of its
	 * operands.
	 **/
	public boolean arithmeticExpressionTypeDerivation() {
		return this.getImpl().arithmeticExpressionTypeDerivation();
	}

	/**
	 * An arithmetic expression has a multiplicity lower bound of 0 if the lower
	 * bound if either operand expression is 0 and 1 otherwise.
	 **/
	public boolean arithmeticExpressionLowerDerivation() {
		return this.getImpl().arithmeticExpressionLowerDerivation();
	}

	/**
	 * An arithmetic expression has a multiplicity upper bound of 1.
	 **/
	public boolean arithmeticExpressionUpperDerivation() {
		return this.getImpl().arithmeticExpressionUpperDerivation();
	}

	/**
	 * The operands of an arithmetic expression must both have type Integer,
	 * unless the operator is +, in which case they may also both have type
	 * String.
	 **/
	public boolean arithmeticExpressionOperandTypes() {
		return this.getImpl().arithmeticExpressionOperandTypes();
	}

	public Collection<ConstraintViolation> checkConstraints() {
		Collection<ConstraintViolation> violations = new ArrayList<ConstraintViolation>();
		this.checkConstraints(violations);
		return violations;
	}

	public void checkConstraints(Collection<ConstraintViolation> violations) {
		super.checkConstraints(violations);
		if (!this.arithmeticExpressionIsConcatenationDerivation()) {
			violations.add(new ConstraintViolation(
					"arithmeticExpressionIsConcatenationDerivation", this));
		}
		if (!this.arithmeticExpressionTypeDerivation()) {
			violations.add(new ConstraintViolation(
					"arithmeticExpressionTypeDerivation", this));
		}
		if (!this.arithmeticExpressionLowerDerivation()) {
			violations.add(new ConstraintViolation(
					"arithmeticExpressionLowerDerivation", this));
		}
		if (!this.arithmeticExpressionUpperDerivation()) {
			violations.add(new ConstraintViolation(
					"arithmeticExpressionUpperDerivation", this));
		}
		if (!this.arithmeticExpressionOperandTypes()) {
			violations.add(new ConstraintViolation(
					"arithmeticExpressionOperandTypes", this));
		}
	}

	public String toString() {
		return this.toString(false);
	}

	public String toString(boolean includeDerived) {
		return "(" + this.hashCode() + ")"
				+ this.getImpl().toString(includeDerived);
	}

	public String _toString(boolean includeDerived) {
		StringBuffer s = new StringBuffer(super._toString(includeDerived));
		if (includeDerived) {
			s.append(" /isConcatenation:");
			s.append(this.getIsConcatenation());
		}
		return s.toString();
	}

	public void print() {
		this.print("", false);
	}

	public void print(boolean includeDerived) {
		this.print("", includeDerived);
	}

	public void print(String prefix, boolean includeDerived) {
		super.print(prefix, includeDerived);
		if (includeDerived) {
		}
	}
} // ArithmeticExpression
