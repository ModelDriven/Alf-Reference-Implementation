package org.modeldriven.alf.uml;

public interface Property extends StructuralFeature {
    
    public Association getAssociation();

}
