package org.modeldriven.alf.uml;

public enum ParameterDirectionKind {
    in, inout, out, return_
}
