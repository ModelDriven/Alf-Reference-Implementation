package org.modeldriven.alf.uml;

public interface TypedElement extends NamedElement {
    
    public Type getType();

}
