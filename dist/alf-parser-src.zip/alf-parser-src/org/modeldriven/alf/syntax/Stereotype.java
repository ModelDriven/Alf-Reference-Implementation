package org.modeldriven.alf.syntax;

public class Stereotype extends Element {

}
