
/*
 * Copyright 2010 Data Access Technologies, Inc. (Model Driven Solutions)
 *
 * Licensed under the Academic Free License version 3.0 
 * (http://www.opensource.org/licenses/afl-3.0.php) 
 *
 */

package org.modeldriven.alf.syntax.expressions;

import org.modeldriven.alf.syntax.*;
import org.modeldriven.alf.syntax.common.*;
import org.modeldriven.alf.syntax.expressions.*;
import org.modeldriven.alf.syntax.statements.*;
import org.modeldriven.alf.syntax.units.*;

import java.util.ArrayList;

public class BitStringUnaryExpression extends UnaryExpression {

	private boolean isBitStringConversion = false; // DERIVED

	public boolean getIsBitStringConversion() {
		return this.isBitStringConversion;
	}

	public void setIsBitStringConversion(boolean isBitStringConversion) {
		this.isBitStringConversion = isBitStringConversion;
	}

	public String toString() {
		StringBuffer s = new StringBuffer(super.toString());
		return s.toString();
	}

	public void print(String prefix) {
		super.print(prefix);
	}
} // BitStringUnaryExpression
