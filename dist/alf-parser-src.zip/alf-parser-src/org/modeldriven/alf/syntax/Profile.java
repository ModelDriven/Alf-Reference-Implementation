package org.modeldriven.alf.syntax;

public class Profile extends Element {

}
